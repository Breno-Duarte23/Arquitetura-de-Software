package buttons;

public class AndroidButton implements Button{
	@Override
    public void paint() {
        System.out.println("Voc� criou um bot�o do Android");
    }
}
