package checkboxes;

public class AndroidCheckbox implements Checkbox{
	@Override
    public void paint() {
        System.out.println("Voc� criou um checkbox no Android.");
    }
}
